var firstBook  = new Book(); // OK.
var secondBook = new Book; // Bad.
var thirdBook  = new Book    (); // Bad.
var fourthBook = new Book    ( 'title' ); // Bad.
