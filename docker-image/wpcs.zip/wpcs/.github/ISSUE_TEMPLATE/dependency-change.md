---
name: Dependency Change
about: A reminder to take action when a WPCS dependency changes

---

<!-- PLEASE prefix the title the Issue with the dependency name and version when action should be taken e.g. PHPCS 3.5: ... -->

## Rationale

<!-- Why should this change be made in WPCS? -->

## References

<!-- References, like a link to the changelog of the version which contains a feature or the upstream issue which requested it -->
 
 -  ...

## Action Checklist

- [ ] ...
